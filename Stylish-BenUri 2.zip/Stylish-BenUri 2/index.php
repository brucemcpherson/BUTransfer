<!DOCTYPE html>
<html>
<head>
<!-- Global site tag (gtag.js) - Google Analytics -->

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-33082129-4"></script>

<script>

  window.dataLayer = window.dataLayer || [];

  function gtag(){dataLayer.push(arguments);}

  gtag('js', new Date());

  gtag('config', 'UA-33082129-4');

</script>
<meta charset="UTF-8">
<title>Ben Uri gallery collection London</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

<link href="https://fonts.googleapis.com/css?family=Merriweather|Montserrat:400,700|Open+Sans" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto+Slab" rel="stylesheet">
<link rel="stylesheet" type="text/css" media="all" href="css/custom.css" />

<style>

/* The Overlay (background) */
.overlay {
  /* Height & width depends on how you want to reveal the overlay (see JS below) */   
  height: 100%;
  width: 0;
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  background-color: rgb(0,0,0); /* Black fallback color */
  background-color: rgba(0,0,0, 0.9); /* Black w/opacity */
  overflow-x: hidden; /* Disable horizontal scroll */
  transition: 0.5s; /* 0.5 second transition effect to slide in or slide down the overlay (height or width, depending on reveal) */
}

/* Position the content inside the overlay */
.overlay-content {
  position: relative;
  top: 13%; /* 25% from the top */
  width: 100%; /* 100% width */
  text-align: center; /* Centered text/links */
  margin-top: 30px; /* 30px top margin to avoid conflict with the close button on smaller screens */
}

/* The navigation links inside the overlay */
.overlay a {
  padding: 8px;
  text-decoration: none;
  font-size: 36px;
  color: #818181;
  display: block; /* Display block instead of inline */
  transition: 0.3s; /* Transition effects on hover (color) */
}

/* When you mouse over the navigation links, change their color */
.overlay a:hover, .overlay a:focus {
  color: #f1f1f1;
}

/* Position the close button (top right corner) */
.overlay .closebtn {
  position: absolute;
  top: 20px;
  right: 45px;
  font-size: 60px;
}

/* When the height of the screen is less than 450 pixels, change the font-size of the links and position the close button again, so they don't overlap */
@media screen and (max-height: 450px) {
  .overlay a {font-size: 20px}
  .overlay .closebtn {
    font-size: 40px;
    top: 15px;
    right: 35px;
  }
} 

</style>

</head>
<body>

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" href="https://www.benuricollection.org.uk/">Ben Uri Collection</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      
        
	  <li class="nav-item dropdown">
<a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Artists <span class="caret"></span></a>
<div class="dropdown-menu" aria-labelledby="navbarDropdown">
           			
<a class="dropdown-item" href="artist_by_country.php">By country of origin</a>
<a class="dropdown-item" href="artist_keywords.php">Artist keywords</a>
<a class="dropdown-item" href="artist_by_yob.php" class="col-link">By year of birth by decade</a>
<a class="dropdown-item" href="artist_by_yod.php">By year of death by decade</a>
<a class="dropdown-item" href="artist.php">By surname (in A-Z order) with number of works by each</a>
<a class="dropdown-item" href="browse_emigres.php">View work by &eacute;migr&eacute; artists</a>
<a class="dropdown-item" href="female_artists.php">View work by female artists</a>
<a class="dropdown-item" href="male_artists.php">View work by male artists</a>

</div>
</li>
    
<li class="nav-item dropdown">
<a href="collection.php" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Collection 

<span class="caret"></span></a>

<div class="dropdown-menu" aria-labelledby="navbarDropdown">
<a class="dropdown-item" href="collection.php">About the collection</a>
<a class="dropdown-item" href="browse.php">Browse whole collection</a>
<a class="dropdown-item" href="materials_and_techniques.php">Materials and techniques</a>
<a class="dropdown-item" href="items_by_object_type.php">By object type</a>
<a class="dropdown-item" href="keywords.php">By keyword tag</a>
<a class="dropdown-item" href="archive.php">Archive</a>

</div>

</li>
    
<li class="nav-item">
<a class="nav-link" href="search.php">Search</a>
</li>
	  
<li class="nav-item">
<a class="nav-link" href="loans.php">Loans</a>
</li>
	  
    
<li class="nav-item dropdown">
<a href="http://www.benuri.org.uk/" class="nav-link dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Exhibitions 
<span class="caret"></span></a>

<div class="dropdown-menu" aria-labelledby="navbarDropdown">
<a class="dropdown-item" href="http://www.benuri.org.uk/exhibitions" target="_blank">Current exhibitions</a>
<a class="dropdown-item" href="bu_exhibitions.php">Ben Uri exhibitions</a>
<a class="dropdown-item" href="other_exhibitions.php">Other exhibitions</a>
</div>

</li>
    
<li class="nav-item">
<a class="nav-link" href="contact.php">Contact</a>
</li>

<li class="nav-item active">
        <a class="nav-link" target="_blank" href="https://www.benuri.org.uk/">Ben Uri Gallery and Museum <span class="sr-only">(Ben Uri website)</span></a>
      </li>

</ul>

  <!--  <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form> -->
	
	<form action="search.php" method="post" class="form-inline" spellcheck="false">
<input type="search" class="form-control mr-sm-2" name="bu_keyword" placeholder="Search" aria-label="Search">
<input type="hidden" name="submitted" value="1" />
<button type="submit" class="btn btn-info">Search</button>
</form>

  </div>
</nav>

<div class="container">

<div class="row">

<div class="col-md-2">

<img style="padding: 20px 0;" src="images/bu-logo-collex.png" class="img-fluid" />

</div> <!-- end 2 class div for logo -->

<div class="col-md-10 branding">

<h1 style="padding-top: 80px;">Ben Uri collection</h1>

</div>

</div> <!-- end row div -->

<div class="row">

<div class="col-md-6">

<p class="lead">The most comprehensive and important collection of works by late 19th, 20th and 21st Century immigrant artists in the United Kingdom and the international museum sector.</p>

<p>Reflecting Ben Uri's heritage, artworks in the collection are principally by Jewish artists. Since 2001, however, our remit has expanded to include relevant works by immigrant artists to the UK from all national, ethnic and religious origins, who have helped to enrich our cultural landscape.</p>

<h4 style="font-weight: 700;">Find out more</h4>

<ul class="list-group list-group-flush">

<li class="list-group-item"><a href="collection.php">About the collection</a></li>

<li class="list-group-item"><a href="browse.php">Browse whole collection</a></li>

<li class="list-group-item"><span style="color: #666;">Collection</span> <a href="browse_highlights.php">Pre-eminent</a> | <a href="browse_collection.php">Core</a> | <a href="browse_reference_collection.php">Reference</a></li>

<li class="list-group-item">Search by <a href="keywords.php">Keyword tag</a> | <a href="artist_keywords.php">Artist keyword tag</a></li>

<li class="list-group-item"><a href="artist_by_country.php">Search by country of origin</a></li>

<li class="list-group-item"><a href="artist.php">Artists in the collection</a></li>

<!-- Use any element to open/show the overlay navigation menu -->
<li class="list-group-item"><span onclick="openNav()"><a href="#">Show full menu</a></span></li>

</ul>

<!-- The overlay -->
<div id="myNav" class="overlay">

  <!-- Button to close the overlay navigation -->
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>

  <!-- Overlay content -->
  <div class="overlay-content">

  <a href="#" style="text-transform: uppercase;">artists</a>
  
  <a href="artist_keywords.php">Artist keywords</a>

<a href="artist_by_country.php">By 35 countries of origin</a>

<a href="artist_by_yob.php">By year of birth by decade</a>

<a href="artist_by_yod.php">By year of death by decade</a>

<a href="artist.php">By A-Z surname</a>

<a href="browse_emigres.php">View work by &eacute;migr&eacute; artists</a>

<a href="female_artists.php">View work by female artists</a>

<a href="male_artists.php">View work by male artists</a>


  <a href="#" style="text-transform: uppercase;">collection</a>

<a href="browse.php">Browse whole collection</a>

<a href="browse_highlights.php">Pre-eminent collection</a>

<a href="browse_collection.php">Core collection</a>

<a href="browse_reference_collection.php">Reference collection</a>

<a href="materials_and_techniques.php">Materials and techniques</a>

<a href="items_by_object_type.php">By object type</a>

<a href="keywords.php">By keyword tag</a>

<a href="archive.php">Archive</a>

<a href="collection.php">About the collection</a>

  <a href="#" style="text-transform: uppercase;">exhibitions</a>

<a href="https://www.benuri.org" target="_blank">Current exhibitions</a>
<a href="exhibitions.php">Past exhibitions</a>

  
  </div>

</div>

<script>

/* Open when someone clicks on the span element */
function openNav() {
  document.getElementById("myNav").style.width = "100%";
}

/* Close when someone clicks on the "x" symbol inside the overlay */
function closeNav() {
  document.getElementById("myNav").style.width = "0%";
} 

</script>

</div>

<div class="col-md-6">

<img src="https://www.benuricollection.org.uk/images/verybig/2014-01.jpg" alt="Joseph Herman Refugees" border="0" class="img-fluid">

<p class="small" style="padding-top: 20px;"><strong>Refugees</strong> by Josef Herman (1911-2000) <a href="https://www.benuricollection.org.uk/search_result.php?item_id=3030">Find out more</a></p>

</div>

</div>

<div class="row" id="footer">

<div class="col-md-8">
<h4>Ben Uri Gallery and Museum <span class="small">Art, Identity & Migration</span></h4>
<!-- <h6>The Art Museum for Everyone</h6> -->
<p> 108A Boundary Road, London NW8 0RH <span class="footerbold">Tel:</span> +44 (0)207 604 3991 <a href="https://www.benuri.org.uk">www.benuri.org.uk</a></p>

<!-- <p>Sarah MacDougall, Head of Collections <span class="bu">sarahm@benuri.org.uk</span></p> -->
<!-- <h6>The London Jewish Museum of Art</h6> -->

<p><!-- <span>Registered Museum</span> 973 | --> <span>Registered Charity</span> 280389</p>
<!-- <p><span class="footerbold">Founded</span> in Whitechapel, London &mdash; Bridging Communities since 1915</p> -->

</div> <!-- end 10 class div -->

<div class="col-md-2">

<div class="ssk-group ssk-grayscale">
    <a href="https://www.facebook.com/BenUriGallery/?ref=page_internal" class="ssk ssk-facebook"></a>
    <a href="https://twitter.com/BenUriGallery" class="ssk ssk-twitter"></a>
    <a href="https://www.youtube.com/user/BenUriGallery/featured" class="ssk ssk-youtube"></a>

</div>

</div> <!-- end 2 class div -->

<div class="col-md-2">

<img style="padding: 20px 0;" src="images/bu-logo.png" class="img-fluid" />

</div> <!-- end 2 class div for logo -->

</div> <!-- end footer row div -->

</div> <!-- end container div -->

<script src="lightbox/js/lightbox.js"></script>

<script>
    lightbox.option({
      'fitImagesInViewport': false,
	  'positionFromTop': 10,
	  'positionFromBottom': 10
    });
</script>

</body>
</html>